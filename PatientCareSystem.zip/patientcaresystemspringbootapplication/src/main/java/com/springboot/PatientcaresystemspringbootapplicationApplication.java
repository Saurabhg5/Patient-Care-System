package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientcaresystemspringbootapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientcaresystemspringbootapplicationApplication.class, args);
	}

}
