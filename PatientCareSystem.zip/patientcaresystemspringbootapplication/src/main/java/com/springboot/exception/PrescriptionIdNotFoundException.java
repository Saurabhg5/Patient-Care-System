package com.springboot.exception;

public class PrescriptionIdNotFoundException extends RuntimeException {
	
	public PrescriptionIdNotFoundException(String message)
	{
		
		super(message);
		
	}

}