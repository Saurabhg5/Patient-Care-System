package com.springboot.exception;

public class AppointmentIdNotFoundException extends RuntimeException{
	
	public AppointmentIdNotFoundException(String message)
	{
		
		super(message);
		
	}

}
