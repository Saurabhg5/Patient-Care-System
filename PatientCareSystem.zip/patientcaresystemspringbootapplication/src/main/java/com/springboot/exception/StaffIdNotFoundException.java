package com.springboot.exception;

public class StaffIdNotFoundException extends RuntimeException{
	
	public StaffIdNotFoundException(String message)
	{
		
		super(message);
		
	}

}