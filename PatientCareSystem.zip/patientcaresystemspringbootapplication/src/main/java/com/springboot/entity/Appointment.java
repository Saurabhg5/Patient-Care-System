package com.springboot.entity;

import java.time.LocalDate;


import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor        // default constructor
@AllArgsConstructor        // parameterized constructor
@ToString                // to string method
@Entity
@Table(name = "appointments")
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int appointmentId;

    
    @Column(nullable = false)
//    @NotBlank(message = "Appointment date can not be blank.")
    @FutureOrPresent(message = "Appointment date must be today or in the future.")
    private LocalDate appointmentDate;

    
    
    @Column(length = 25, nullable = false)
  @NotBlank(message = "Patient name can not be blank.")
  private String patientName;
    
    
//    @Column(length = 25, nullable = false)
//    @NotBlank(message = "Appointment status name can not be blank.")
//    private String appointmentStatus;

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
//    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//    @JoinColumn(name = "pId", referencedColumnName = "patientId")
//    @JsonBackReference
//    private Patient patient;
//
//    
//    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//    @JoinColumn(name = "dId", referencedColumnName = "doctorId")
//    @JsonBackReference
//    private Doctor doctor;
}
