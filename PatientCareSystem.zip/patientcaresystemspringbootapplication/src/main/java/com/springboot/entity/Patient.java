package com.springboot.entity;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor		//default constructor
@AllArgsConstructor		//parameterized constructor
@ToString				//to string method
@Entity
@Table(name = "patients")
public class Patient {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int patientId;
	
	
	@Column(length=25, nullable = false)						//nullable - do not null field
	@NotBlank(message="Patient name can not be blank..") 		// validation
	private String patientName;
	
	
	@Column(nullable = false)
	@NotNull(message = "Patient date of birth cannot be null.")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate patientDateOfBirth;
	
	
	@Column(length = 6, nullable = false)
	@NotBlank(message = "Patient gender can not be blank..")
	private String patientGender;
	
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "Patient address can not be blank..")
	private String patientAddress;
	
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Patient Blood Group can not be blank..")
	private String patientBloodGroup;
	
	
	
	@Column(length = 10, nullable = false, unique = true)
	@Size(min=10,max=10)
	@NotBlank(message = "Patient phone number can not be blank..")
	@Pattern(regexp="(^$|[0-9]{10})")
	private String patientPhoneNo;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//appointment
//	@OneToMany(mappedBy = "patient",  
//	fetch = FetchType.EAGER, cascade = CascadeType.ALL)		//CascadeType = changing the value
//	@JsonManagedReference
//	private List<Appointment> appointmentList;
	
	
	
	//prescription
//	@OneToMany(mappedBy = "patient",  
//			fetch = FetchType.EAGER, cascade = CascadeType.ALL)		//CascadeType = changing the value
//			@JsonManagedReference
//			private List<Prescription> prescriptionList;
	
	
	//payment
//	@OneToMany(mappedBy = "patient",  
//			fetch = FetchType.EAGER, cascade = CascadeType.ALL)		//CascadeType = changing the value
//			@JsonManagedReference
//			private List<Payment> paymentList;
	
	
	
	
	
	
	
	
	
//	@OneToMany(mappedBy = "patient",  
//			fetch = FetchType.EAGER, cascade = CascadeType.ALL)		//CascadeType = changing the value
//			@JsonManagedReference
//			private List<Doctor> doctorList;
	
	
	
	

//	@OneToMany(mappedBy = "patient")
//    @JsonManagedReference("patient-appointment")
//    private List<Appointment> appointmentList;

	
	
	
//	@OneToOne(mappedBy = "patient", cascade = CascadeType.ALL)
//    private Appointment appointment;
}
