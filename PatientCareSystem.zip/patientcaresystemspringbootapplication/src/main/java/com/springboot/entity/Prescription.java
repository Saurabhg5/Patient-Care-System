package com.springboot.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "prescriptions")
public class Prescription {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int prescriptionId;
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Prescription dose can not be Blank")
	private String dose;
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Prescription duration can not be Blank")
	private String duration;
	
	
	
	
	
	
	
	
	
	
	
	
	
//	@OneToMany(mappedBy = "prescription",  
//			fetch = FetchType.EAGER, cascade = CascadeType.ALL)		//CascadeType = changing the value
//			@JsonManagedReference
//			private List<Medicine> medicineList;
//	
//	
//	
//	@ManyToOne(fetch =FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name="docId", referencedColumnName = "doctorId")
//	@JsonBackReference
//	private Doctor doctor;
//	
//	
//	
//	
//	@ManyToOne(fetch =FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name="pId", referencedColumnName = "patientId")
//	@JsonBackReference
//	private Patient patient;
	
		

}
