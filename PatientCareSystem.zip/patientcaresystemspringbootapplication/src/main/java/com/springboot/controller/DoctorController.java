package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.entity.Doctor;
import com.springboot.service.DoctorService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v2/")
public class DoctorController {
	
	@Autowired
	DoctorService doctorService;
	
	
	
	@PostMapping("/Doctor/addDoctor")
	public ResponseEntity<Doctor> saveDoctor(@Valid @RequestBody Doctor doctor) 
	{
		
		return new ResponseEntity<Doctor>(doctorService.addDoctor(doctor), HttpStatus.CREATED);
		
	}
	
	
	
	@GetMapping("/Doctor")
	public List<Doctor> getAllDoctorSchedules(){
		
		return doctorService.getAllDoctors();
	}	
	
	
	
	@GetMapping("/Doctor/{doctorId}")
	public ResponseEntity<Doctor> getDoctorById(@PathVariable ("doctorId") int doctorId)
	{
		return new ResponseEntity<Doctor>(doctorService.getDoctorById(doctorId),HttpStatus.OK);
	}
	
	
	
//	@GetMapping("/Doctor")
//	public List<Doctor> getAllDoctorByName(String doctorName){
//		
//		return doctorService.getDoctorByName(doctorName);
//	}	
	
	
	
	@DeleteMapping("/Doctor/{doctorId}")
	public ResponseEntity<String> deleteDoctor(@PathVariable ("doctorId") int doctorId)
	{
		doctorService.deleteDoctor(doctorId);
		return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
	}
	
	
	
	
	
	@PutMapping("/Doctor/{doctorId}")
    public ResponseEntity<String> updateDoctor(@RequestBody Doctor doctor, @PathVariable("doctorId") int doctorId) {
		doctorService.updateDoctor(doctor, doctorId); 										// Delegate to service layer
        return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
    }

}
