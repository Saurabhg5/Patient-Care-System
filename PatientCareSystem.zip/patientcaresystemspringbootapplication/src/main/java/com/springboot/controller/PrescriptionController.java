package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.entity.Prescription;
import com.springboot.service.PrescriptionService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v7/")
public class PrescriptionController {
	
	@Autowired
	PrescriptionService prescriptionService;
	
	
	
	@PostMapping("/Prescription")
	public ResponseEntity<Prescription> savePrescription(@Valid @RequestBody Prescription prescription) 
	{
		
		return new ResponseEntity<Prescription>(prescriptionService.addPrescription(prescription), HttpStatus.CREATED);
		
	}
	
	@GetMapping("/Prescription")
	public List<Prescription> getAllPrescriptions(){
		
		return prescriptionService.getAllPrescriptions();
	}
	
	
	
	@GetMapping("/Prescription/{prescriptionId}")
	public ResponseEntity<Prescription> getPrescriptionById(@PathVariable ("prescriptionId") int prescriptionId)
	{
		return new ResponseEntity<Prescription>(prescriptionService.getPrescriptionById(prescriptionId), HttpStatus.OK);
	}
	
	
	
	
	@DeleteMapping("/Prescription/{prescriptionId}")
	public ResponseEntity<String> deletePrescription(@PathVariable ("prescriptionId") int prescriptionId)
	{
		prescriptionService.deletePrescription(prescriptionId);
		return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
	}
	
	
	
	
	@PutMapping("/Prescription/{prescriptionId}")
    public ResponseEntity<String> updatePrescription(@RequestBody Prescription prescription, @PathVariable("prescriptionId") int prescriptionId) {
		prescriptionService.updatePrescription(prescription, prescriptionId); 										// Delegate to service layer
        return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
    }

}
