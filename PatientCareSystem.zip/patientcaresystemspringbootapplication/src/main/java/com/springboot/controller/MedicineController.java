package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.entity.Medicine;
import com.springboot.service.MedicineService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v4/")
public class MedicineController {
	
	@Autowired
	MedicineService medicineService;
	
	
	
	@PostMapping("/Medicine")
	public ResponseEntity<Medicine> saveMedicine(@Valid @RequestBody Medicine medicine) 
	{
		
		return new ResponseEntity<Medicine>(medicineService.addMedicine(medicine), HttpStatus.CREATED);
		
	}
	
	
	
	
	@GetMapping("/Medicine")
	public List<Medicine> getAllMedicines(){
		
		return medicineService.getAllMedicines();
	}
	
	
	
	
	@GetMapping("/Medicine/{medicineId}")
	public ResponseEntity<Medicine> getMedicineById(@PathVariable ("medicineId") int medicineId)
	{
		return new ResponseEntity<Medicine>(medicineService.getMedicineById(medicineId), HttpStatus.OK);
	}
	
	
	
//	@GetMapping("/Medicine")
//	public List<Medicine> getMedicineByName(String medicineName){
//		
//		return medicineService.getMedicineByName(medicineName);
//	}	
	
	
	
	
	
	@DeleteMapping("/Medicine/{medicineId}")
	public ResponseEntity<String> deleteMedicine(@PathVariable ("medicineId") int medicineId)
	{
		medicineService.deleteMedicine(medicineId);
		return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
	}
	
	
	
	
	
	
	@PutMapping("/Medicine/{medicineId}")
    public ResponseEntity<String> updateMedicine(@RequestBody Medicine medicine, @PathVariable("medicineId") int medicineId) {
		medicineService.updateMedicine(medicine, medicineId); 										// Delegate to service layer
        return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
    }

}
