package com.springboot.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.springboot.entity.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
	
//	@Query("SELECT a FROM Appointment a WHERE a.appointmentDate = :date")
//	List<Appointment> findAppointmentByDate(@Param("date") LocalDate date);

}
