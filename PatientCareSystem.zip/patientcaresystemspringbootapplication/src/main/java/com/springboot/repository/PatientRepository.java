package com.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.springboot.entity.Patient;

public interface PatientRepository extends JpaRepository<Patient, Integer> {
	
//	@Query("select p from Patient where p.patientName=?1")
//	List<Patient> findPatientByName(String patientName);
//	
//	@Query("select p from Patient where p.patientEmailId=?1")
//	Patient findPatientByEmailId(String patientEmailId);
//	
//	@Query("select p from Patient where p.patientPhoneNo=?1 ")
//	Patient findPatientByPhoneNo(int patientPhoneNo);
//	
//	@Query("select p from Patient p where p.patientBloodGroup = ?1")
//	List<Patient> findPatientByBloodGroup(String patientBloodgroup);
	
	
}
