package com.springboot.service;

import java.util.List;

import com.springboot.entity.DoctorSchedule;

public interface DoctorScheduleService {
	
				DoctorSchedule addDoctorSchedule(DoctorSchedule doctorSchedule);
				
				List<DoctorSchedule> getAllDoctorSchedules();
				
				DoctorSchedule getDoctorScheduleById(int doctorScheduleId);
				
				DoctorSchedule updateDoctorSchedule(DoctorSchedule doctorSchedule, int doctorScheduleId);
				
				void deleteDoctorSchedule(int doctorScheduleId);

}
