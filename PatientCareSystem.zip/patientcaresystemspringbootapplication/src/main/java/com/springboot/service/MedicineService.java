package com.springboot.service;

import java.util.List;

import com.springboot.entity.Medicine;

public interface MedicineService {
	
				
				Medicine addMedicine(Medicine medicine);
				
				
				List<Medicine> getAllMedicines();
				
				
				Medicine getMedicineById(int medicineId);
				
				
//				List<Medicine> getMedicineByName(String medicineName);
				
				
				Medicine updateMedicine(Medicine medicine, int medicineId);
				
				
				void deleteMedicine(int medicineId);	

}
