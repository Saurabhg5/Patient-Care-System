package com.springboot.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.entity.Medicine;
import com.springboot.exception.MedicineIdNotFoundException;
import com.springboot.repository.MedicineRepository;
import com.springboot.service.MedicineService;

@Service
public class MedicineServiceImpl implements MedicineService {

	@Autowired
	MedicineRepository medicineRepository;
	
	
	@Override
	public Medicine addMedicine(Medicine medicine) {
		
		return medicineRepository.save(medicine);
	}

	
	@Override
	public List<Medicine> getAllMedicines() {
		
		return medicineRepository.findAll();
	}
	
	
	@Override
	public Medicine getMedicineById(int medicineId) {

		return medicineRepository.findById(medicineId).
				orElseThrow(()-> new MedicineIdNotFoundException("Medicine id is not corrected"));
	}
	
	
//	@Override
//	public List<Medicine> getMedicineByName(String medicineName) {
//		
//		return medicineRepository.findMedicineByName(medicineName);
//	}
	

	@Override
	public Medicine updateMedicine(Medicine medicine, int medicineId) {
		
		Medicine UpdateMedicine =  medicineRepository.findById(medicineId).
				orElseThrow(()-> new MedicineIdNotFoundException("Medicine id is not corrected"));
		
				// set new value
				UpdateMedicine.setMedicineDescription(medicine.getMedicineDescription());
				UpdateMedicine.setMedicinePrice(medicine.getMedicinePrice());
			
				medicineRepository.save(UpdateMedicine);
				return UpdateMedicine;
	}

	
	@Override
	public void deleteMedicine(int medicineId) {

		Medicine deleteMedicine = medicineRepository.findById(medicineId).
				orElseThrow(()-> new MedicineIdNotFoundException("Medicine id is not corrected"));
				medicineRepository.delete(deleteMedicine);	
		
	}	

}
