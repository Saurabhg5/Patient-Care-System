package com.springboot.serviceimpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.entity.Payment;
import com.springboot.exception.PaymentIdNotFoundException;
import com.springboot.repository.PaymentRepository;
import com.springboot.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	PaymentRepository paymentRepository;
	
	@Override
	public Payment addPayment(Payment payment) {


		return paymentRepository.save(payment);
	}
	
	
	
	@Override
	public List<Payment> getAllPayments() {
		
		return paymentRepository.findAll();
	}
	
	
	

	@Override
	public Payment getPaymentById(int paymentId) {
		
		return paymentRepository.findById(paymentId).
				orElseThrow(()-> new PaymentIdNotFoundException("Payment id is not corrected.."));
	}
	
	
	
	
	@Override
	public Payment updatePayment(Payment payment, int paymentId) {
		
		Payment updatePayment = paymentRepository.findById(paymentId).
				orElseThrow(()-> new PaymentIdNotFoundException("Payment id is not corrected"));
		
				// set new value
			updatePayment.setPaymentAmount(payment.getPaymentAmount());
			updatePayment.setPaymentDate(payment.getPaymentDate());
			updatePayment.setPaymentMethod(payment.getPaymentMethod());
			updatePayment.setPatientName(payment.getPatientName());
			
			paymentRepository.save(updatePayment);
			return updatePayment;

	}
	
	
	

	@Override
	public void deletePayment(int paymentId) {

		Payment deletePayment = paymentRepository.findById(paymentId).
				orElseThrow(()-> new PaymentIdNotFoundException("Payment id is not corrected"));
				paymentRepository.delete(deletePayment);
		
	}
	
	

	

	

//	@Override
//	public List<Payment> getPaymentByDate(LocalDateTime PaymentDate) {
//		
//		return paymentRepository.findPaymentByDate(PaymentDate);
//	}

}
