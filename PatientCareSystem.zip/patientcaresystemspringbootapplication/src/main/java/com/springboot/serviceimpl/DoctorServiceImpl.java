package com.springboot.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.entity.Doctor;
import com.springboot.exception.DoctorIdNotFoundException;
import com.springboot.repository.DoctorRepository;
import com.springboot.service.DoctorService;

@Service
public class DoctorServiceImpl implements DoctorService{

	@Autowired
	DoctorRepository doctorRepository;
	
	@Override
	public Doctor addDoctor(Doctor doctor) {
		
		return doctorRepository.save(doctor);
	}
	
	
	@Override
	public List<Doctor> getAllDoctors() {
		
		return doctorRepository.findAll();
	}
	

	@Override
	public Doctor getDoctorById(int doctorId) {
		
		return doctorRepository.findById(doctorId).
				orElseThrow(()-> new DoctorIdNotFoundException("Doctor id is not corrected"));
	}
	
	
//	@Override
//	public List<Doctor> getDoctorByName(String doctorName) {
//		
//		return doctorRepository.findDoctorByName(doctorName);
//	}
	

	@Override
	public Doctor updateDoctor(Doctor doctor, int doctorId) {
		
		Doctor UpdateDoctor = doctorRepository.findById(doctorId).
				orElseThrow(()-> new DoctorIdNotFoundException("Doctor id is not corrected"));
		
				// set new value
				UpdateDoctor.setDoctorPhoneNo(doctor.getDoctorPhoneNo());
				UpdateDoctor.setDoctorAddress(doctor.getDoctorAddress());
				
			
				doctorRepository.save(UpdateDoctor);
				return UpdateDoctor;
	}
	

	@Override
	public void deleteDoctor(int doctorId) {
		
		Doctor deleteDoctor = doctorRepository.findById(doctorId).
				orElseThrow(()-> new DoctorIdNotFoundException("Doctor id is not corrected"));
				doctorRepository.delete(deleteDoctor);		
		
	}

}
